
from flask import Flask, request, jsonify
app = Flask(__name__)

@app.route("/")
def home():
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Infinity-1 Interface</title>
        <style>
            body { background: black; color: #00f7ef; font-family: Courier New; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; margin: 0; }
            h1 { font-size: 2em; margin-bottom: 20px; }
            input, button { padding: 10px; font-size: 1em; margin: 10px; background: #111; border: 1px solid #00f7ef; color: #00f7ef; }
        </style>
    </head>
    <body>
        <h1>Infinity-1: Speak Your Signal</h1>
        <input type="text" id="user_input" placeholder="Enter your transmission..." />
        <button onclick="sendMessage()">Transmit</button>
        <p id="response"></p>
        <script>
            async function sendMessage() {
                const input = document.getElementById('user_input').value;
                const res = await fetch('/ask', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ message: input })
                });
                const data = await res.json();
                document.getElementById('response').innerText = data.response;
            }
        </script>
    </body>
    </html>
    '''

@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json()
    user_input = data.get("message", "")
    response = f"Infinity-1 hears you. Processing: {user_input}... Reality shift in progress."
    return jsonify({"response": response})

if __name__ == "__main__":
    app.run(debug=True)
